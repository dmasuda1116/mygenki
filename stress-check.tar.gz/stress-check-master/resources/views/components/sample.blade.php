<div>開始</div>
<div>{{ $slot }}</div>
<div>Message:{{ $message }}</div>
<div>Today:{{ $today }}</div>
<div>終了</div>