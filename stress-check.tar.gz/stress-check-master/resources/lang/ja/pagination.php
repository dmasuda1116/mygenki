<?php

return [
    'next'     => '次 &raquo;',
    'previous' => '&laquo; 前',
];
